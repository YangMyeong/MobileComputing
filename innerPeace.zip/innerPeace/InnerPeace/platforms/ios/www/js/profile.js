document.getElementById('saveButton').addEventListener('click', function () {
    alert('Information saved');
});
