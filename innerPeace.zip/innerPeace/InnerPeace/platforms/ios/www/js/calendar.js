document.addEventListener("DOMContentLoaded", function () {
    var selectedDates = []; // 선택된 날짜들을 저장할 배열

    var calendarContainer = document.getElementById("weekCalendar");
    var graphContainer = document.getElementById("graphContainer");

    calendarContainer.addEventListener("click", function (event) {
        var clickedCell = event.target;
        if (clickedCell.classList.contains("calendar-cell")) {
            // 선택한 날짜를 가져옵니다.
            var selectedDate = clickedCell.textContent;

            // 선택된 날짜가 이미 배열에 있는지 확인합니다.
            var index = selectedDates.indexOf(selectedDate);
            if (index > -1) {
                // 이미 선택된 날짜라면 배열에서 제거합니다.
                selectedDates.splice(index, 1);
                clickedCell.classList.remove("today");
            } else {
                // 선택된 날짜가 아니라면 배열에 추가합니다.
                selectedDates.push(selectedDate);
                clickedCell.classList.add("today");
            }

            // 그래프를 그립니다.
            var graphHTML = generateGraph(selectedDates);
            graphContainer.innerHTML = graphHTML;
        }
    });

    // 그래프를 생성하는 함수
    function generateGraph(data) {
        var graphHTML = '';

        graphHTML += '<div class="graph">';
        graphHTML += '<div class="graph-line" style="background-color: red;"></div>';
        graphHTML += '</div>';

        return graphHTML;
    }
});
