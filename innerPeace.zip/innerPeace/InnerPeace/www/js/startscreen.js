const innerPeaceButton = document.getElementById('innerPeaceButton');

innerPeaceButton.addEventListener('click', function () {
    window.location.href = 'Input.html';
});
