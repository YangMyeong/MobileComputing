function navigateTo(url) {
    window.location.href = url;
}

document.getElementById("inviteButton").addEventListener("click", function () {
    alert("Invitation completed!");
});
