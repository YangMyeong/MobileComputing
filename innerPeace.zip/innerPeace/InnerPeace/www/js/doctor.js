function sendQuestion() {
    alert("Your question has been sent.");
}
