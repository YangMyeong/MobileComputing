const innerPeaceButton = document.getElementById('innerPeaceButton');
const goButton = document.getElementById('goButton');

innerPeaceButton.addEventListener('click', function () {
    window.location.href = '../html/selection.html';
});

goButton.addEventListener('click', function () {
    window.location.href = '../html/selection.html';
});
