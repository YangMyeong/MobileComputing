function openLoginPage() {
  document.getElementById('login-page').classList.remove('hidden');
}

function login() {
  var username = document.getElementById('username').value;
  var password = document.getElementById('password').value;

  // You can add your login logic here
  // For this example, let's just log the values to the console
  console.log("Username:", username);
  console.log("Password:", password);
}